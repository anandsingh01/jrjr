<h3 class="fs-subtitle">Fill all the details?</h3>
<!-- Begin Average Gift Size in Year 1 Field -->
<div class="form-item webform-component webform-component-textfield hs_average_gift_size_in_year_1 field hs-form-field" id="edit-submitted-cultivation-amount-1 average_gift_size_in_year_1-99a6d115-5e68-4355-a7d0-529207feb0b3_3256">
    <label for="edit-submit">First Name</label>
    <input id="" class="form-text hs-input" name="f_name" required="required" size="60" maxlength="128"
           type="text" value="" placeholder="" data-rule-required="true" data-msg-required="Please enter a valid number">
    <span class="error1" style="display: none;"><i class="error-log fa fa-exclamation-triangle"></i></span>
</div>
<!-- End Average Gift Size in Year 1 Field -->
<!-- Begin Average Gift Size in Year 1 Field -->
<div class="form-item webform-component webform-component-textfield hs_average_gift_size_in_year_1 field hs-form-field" id="edit-submitted-cultivation-amount-1 average_gift_size_in_year_1-99a6d115-5e68-4355-a7d0-529207feb0b3_3256">
    <label for="">Last Name</label>
    <input id="" class="form-text hs-input" name="l_name" required="required" size="60" maxlength="128"
           type="text" value="" placeholder="" data-rule-required="true" data-msg-required="Please enter a valid number">
    <span class="error1" style="display: none;"><i class="error-log fa fa-exclamation-triangle"></i></span>
</div>
<!-- End Average Gift Size in Year 1 Field -->
<!-- Begin Average Gift Size in Year 1 Field -->
<div class="form-item webform-component webform-component-textfield" id="edit-submitted-cultivation-amount-1 average_gift_size_in_year_1-99a6d115-5e68-4355-a7d0-529207feb0b3_3256">
    <label for="">Mobile No.</label>
    <input id="" class="form-text hs-input" name="mobile" required="required" size="60" maxlength="128"
           type="text" value="" placeholder="" data-rule-required="true" data-msg-required="Please enter a valid number">
    <span class="error1" style="display: none;"><i class="error-log fa fa-exclamation-triangle"></i></span>
</div>
<!-- End Average Gift Size in Year 1 Field -->
<!-- Begin Average Gift Size in Year 1 Field -->
<div class="form-item webform-component webform-component-textfield" id="edit-submitted-cultivation-amount-1 average_gift_size_in_year_1-99a6d115-5e68-4355-a7d0-529207feb0b3_3256">
    <label for="">Whatsapp No.</label>
    <input id="" class="form-text hs-input" name="whatsapp" required="required" size="60" maxlength="128"
           type="text" value="" placeholder="" data-rule-required="true" data-msg-required="Please enter a valid number">
    <span class="error1" style="display: none;"><i class="error-log fa fa-exclamation-triangle"></i></span>
</div>
<!-- End Average Gift Size in Year 1 Field -->

<!-- Begin Average Gift Size in Year 1 Field -->
<div class="form-item webform-component webform-component-textfield" id="edit-submitted-cultivation-amount-1 average_gift_size_in_year_1-99a6d115-5e68-4355-a7d0-529207feb0b3_3256">
    <label for="">Email ID</label>
    <input id="" class="form-text hs-input" name="email" required="required" size="60" maxlength="128"
           type="email" value="" placeholder="" data-rule-required="true" data-msg-required="Please enter a valid email">
    <span class="error1" style="display: none;"><i class="error-log fa fa-exclamation-triangle"></i></span>
</div>
<!-- End Average Gift Size in Year 1 Field -->
