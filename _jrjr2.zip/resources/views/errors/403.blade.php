@extends('layouts.header')
@section('css')
    <title>Page Not Found</title>
@stop
@section('content')
    <section>
        <div class="gap">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="about-us">

                            <h4 class="text-center">404 Page not found!</h4>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- volunteer info section -->
@endsection
